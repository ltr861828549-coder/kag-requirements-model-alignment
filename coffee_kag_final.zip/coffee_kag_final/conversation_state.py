import os
import json
from typing import Any


class ConversationState:
    def __init__(self, session_id: str, storage_path: str = "./state_store"):
        self.session_id = session_id
        self.storage_path = storage_path
        os.makedirs(self.storage_path, exist_ok=True)
        self.file_path = os.path.join(self.storage_path, f"{self.session_id}_state.json")

        self._init_empty()
        self.load()

    def _init_empty(self) -> None:
        self.last_query_module: str | None = None
        self.last_impacted_modules: list[str] = []
        self.last_frontier: list[str] = []
        self.visited_modules: set[str] = set()
        self.last_paths: list[dict[str, Any]] = []

    def update_from_analysis(
        self,
        query_module: str,
        impacted_modules: list[str],
        paths: list[dict[str, Any]],
    ) -> None:
        self.last_query_module = query_module
        self.last_impacted_modules = impacted_modules[:]
        self.last_frontier = impacted_modules[:]
        self.last_paths = paths[:]

        self.visited_modules.add(query_module)
        for module_id in impacted_modules:
            self.visited_modules.add(module_id)

    def update_frontier(self, new_frontier: list[str]) -> None:
        self.last_frontier = new_frontier[:]
        for module_id in new_frontier:
            self.visited_modules.add(module_id)

    def has_frontier(self) -> bool:
        return len(self.last_frontier) > 0

    def clear(self) -> None:
        self._init_empty()
        self.save()

    def save(self) -> None:
        data = {
            "last_query_module": self.last_query_module,
            "last_impacted_modules": self.last_impacted_modules,
            "last_frontier": self.last_frontier,
            "visited_modules": list(self.visited_modules),
            "last_paths": self.last_paths,
        }
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def load(self) -> None:
        if not os.path.exists(self.file_path):
            return

        with open(self.file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        self.last_query_module = data.get("last_query_module")
        self.last_impacted_modules = data.get("last_impacted_modules", [])
        self.last_frontier = data.get("last_frontier", [])
        self.visited_modules = set(data.get("visited_modules", []))
        self.last_paths = data.get("last_paths", [])