from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any
from neo4j import GraphDatabase

from config import URI, USER, PASSWORD


driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))

ALLOWED_REL_TYPES = ["COMPOSITION", "DEPENDENCY", "FLOW", "ASSOCIATION"]
REL_TYPE_CYPHER = "|".join(ALLOWED_REL_TYPES)


def _normalize(text: str | None) -> str:
    return (text or "").strip()


def _dedup_candidates(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen = set()
    result = []
    for item in items:
        node_id = item.get("id")
        if node_id and node_id not in seen:
            seen.add(node_id)
            result.append(item)
    return result


def find_module_candidates(module_name: str, limit: int = 10) -> list[dict[str, str]]:
    keyword = _normalize(module_name)
    if not keyword:
        return []

    exact_query = """
    MATCH (n:SysML_Element)
    WHERE toLower(n.id) = toLower($name)
       OR n.name = $name
    RETURN n.id AS id, n.name AS name, n.type AS type,
           100 AS score
    LIMIT $limit
    """

    contain_query = """
    MATCH (n:SysML_Element)
    WHERE toLower(n.id) CONTAINS toLower($name)
       OR n.name CONTAINS $name
    RETURN n.id AS id, n.name AS name, n.type AS type,
           CASE
             WHEN n.name = $name THEN 95
             WHEN toLower(n.id) = toLower($name) THEN 95
             WHEN n.name STARTS WITH $name THEN 80
             WHEN toLower(n.id) STARTS WITH toLower($name) THEN 80
             ELSE 60
           END AS score
    ORDER BY score DESC, size(n.name) DESC, n.id ASC
    LIMIT $limit
    """

    with driver.session() as session:
        exact_records = list(session.run(exact_query, name=keyword, limit=limit))
        contain_records = list(session.run(contain_query, name=keyword, limit=limit))

    candidates: list[dict[str, Any]] = []
    for records in [exact_records, contain_records]:
        for record in records:
            candidates.append({
                "id": record["id"],
                "name": record["name"],
                "type": record["type"],
                "score": record.get("score", 0),
            })

    candidates = _dedup_candidates(candidates)
    candidates.sort(key=lambda x: (-int(x.get("score", 0)), -len(str(x.get("name", ""))), str(x.get("id", ""))))
    return [
        {"id": item["id"], "name": item["name"], "type": item["type"]}
        for item in candidates[:limit]
    ]


def get_multihop_paths(module_id: str, max_hops: int = 3) -> list[dict[str, Any]]:
    query = f"""
    MATCH p = (start:SysML_Element {{id: $module_id}})
              -[:{REL_TYPE_CYPHER}*1..{max_hops}]->
              (n:SysML_Element)
    WHERE start <> n
    RETURN p
    ORDER BY length(p) ASC
    """
    results: list[dict[str, Any]] = []

    with driver.session() as session:
        records = session.run(query, module_id=module_id)
        for record in records:
            path = record["p"]

            node_list = []
            rel_list = []

            for node in path.nodes:
                node_list.append({
                    "id": node.get("id"),
                    "name": node.get("name"),
                    "type": node.get("type"),
                })

            for rel in path.relationships:
                rel_list.append({
                    "type": rel.type,
                    "arrow": rel.get("arrow", ""),
                    "desc": rel.get("desc", ""),
                })

            results.append({
                "length": len(path.relationships),
                "nodes": node_list,
                "relationships": rel_list,
            })

    return results


def collect_impacted_modules(paths: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    impacted: dict[str, dict[str, Any]] = {}

    for path in paths:
        length = int(path["length"])
        nodes = path["nodes"]
        rels = path.get("relationships", [])

        for idx, node in enumerate(nodes[1:], start=1):
            node_id = node["id"]
            incoming_rel = rels[idx - 1] if idx - 1 < len(rels) else {}
            rel_type = incoming_rel.get("type", "")

            if node_id not in impacted:
                impacted[node_id] = {
                    "id": node["id"],
                    "name": node["name"],
                    "type": node["type"],
                    "min_hop": length,
                    "path_count": 1,
                    "via_relation_types": [rel_type] if rel_type else [],
                }
            else:
                impacted[node_id]["min_hop"] = min(impacted[node_id]["min_hop"], length)
                impacted[node_id]["path_count"] += 1
                if rel_type and rel_type not in impacted[node_id]["via_relation_types"]:
                    impacted[node_id]["via_relation_types"].append(rel_type)

    return impacted


def build_graph_context(module_id: str, paths: list[dict[str, Any]]) -> str:
    impacted = collect_impacted_modules(paths)

    simple_paths = []
    for path in paths:
        nodes = path["nodes"]
        rels = path.get("relationships", [])

        readable = []
        for i, node in enumerate(nodes):
            node_label = f"{node['name']}({node['id']})"
            readable.append(node_label)
            if i < len(rels):
                rel_type = rels[i].get("type", "")
                rel_desc = rels[i].get("desc", "")
                if rel_desc:
                    readable.append(f"-[{rel_type}:{rel_desc}]->")
                else:
                    readable.append(f"-[{rel_type}]->")

        simple_paths.append({
            "length": path["length"],
            "path": " ".join(readable),
        })

    impacted_list = sorted(
        impacted.values(),
        key=lambda x: (x["min_hop"], -x["path_count"], x["id"])
    )

    context = {
        "changed_module": module_id,
        "allowed_relation_types": ALLOWED_REL_TYPES,
        "impacted_modules": impacted_list,
        "paths": simple_paths,
    }

    return json.dumps(context, ensure_ascii=False, indent=2)


def build_analysis_graph_json(
    start_module: dict[str, Any],
    paths: list[dict[str, Any]],
    user_question: str,
    intent: str,
    llm_answer: str | None = None,
) -> dict[str, Any]:
    nodes_map: dict[str, dict[str, Any]] = {}
    edges_map: dict[tuple[str, str, str, str], dict[str, Any]] = {}

    nodes_map[start_module["id"]] = {
        "id": start_module["id"],
        "name": start_module.get("name", start_module["id"]),
        "type": start_module.get("type", "Unknown"),
        "role": "changed_module",
        "hop": 0,
    }

    for path in paths:
        path_nodes = path.get("nodes", [])
        path_rels = path.get("relationships", [])
        for idx, node in enumerate(path_nodes):
            node_id = node["id"]
            hop = idx
            role = "changed_module" if idx == 0 else "impacted_module"
            existing = nodes_map.get(node_id)
            if existing is None:
                nodes_map[node_id] = {
                    "id": node_id,
                    "name": node.get("name", node_id),
                    "type": node.get("type", "Unknown"),
                    "role": role,
                    "hop": hop,
                }
            else:
                existing["hop"] = min(existing.get("hop", hop), hop)
                if existing.get("role") != "changed_module" and role == "changed_module":
                    existing["role"] = role

            if idx < len(path_rels):
                src = path_nodes[idx]
                dst = path_nodes[idx + 1]
                rel = path_rels[idx]
                key = (
                    src["id"],
                    dst["id"],
                    rel.get("type", "RELATED_TO"),
                    rel.get("desc", ""),
                )
                if key not in edges_map:
                    edges_map[key] = {
                        "source": src["id"],
                        "target": dst["id"],
                        "type": rel.get("type", "RELATED_TO"),
                        "arrow": rel.get("arrow", ""),
                        "desc": rel.get("desc", ""),
                    }

    impacted = collect_impacted_modules(paths)
    impacted_list = sorted(
        impacted.values(),
        key=lambda x: (x["min_hop"], -x["path_count"], x["id"])
    )

    return {
        "meta": {
            "question": user_question,
            "intent": intent,
            "start_module": {
                "id": start_module["id"],
                "name": start_module.get("name", start_module["id"]),
                "type": start_module.get("type", "Unknown"),
            },
            "allowed_relation_types": ALLOWED_REL_TYPES,
            "generated_at": datetime.now().isoformat(timespec="seconds"),
        },
        "summary": {
            "node_count": len(nodes_map),
            "edge_count": len(edges_map),
            "impacted_count": len(impacted_list),
            "path_count": len(paths),
        },
        "nodes": list(nodes_map.values()),
        "edges": list(edges_map.values()),
        "impacted_modules": impacted_list,
        "llm_answer": llm_answer or "",
    }


def save_analysis_json(data: dict[str, Any], output_dir: str = "./analysis_outputs") -> str:
    os.makedirs(output_dir, exist_ok=True)
    module_id = data.get("meta", {}).get("start_module", {}).get("id", "UNKNOWN")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"impact_analysis_{module_id}_{ts}.json"
    file_path = os.path.join(output_dir, filename)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return file_path


def expand_from_frontier(module_ids: list[str], visited_modules=None) -> list[dict[str, str]]:
    if visited_modules is None:
        visited_modules = set()

    module_ids = [m for m in module_ids if _normalize(m)]
    if not module_ids:
        return []

    query = f"""
    MATCH (start:SysML_Element)-[r:{REL_TYPE_CYPHER}]->(n:SysML_Element)
    WHERE start.id IN $module_ids
      AND NOT n.id IN $visited
    RETURN start.id AS start_id,
           n.id AS id,
           n.name AS name,
           n.type AS type,
           type(r) AS rel_type,
           coalesce(r.desc, "") AS rel_desc
    ORDER BY n.id ASC
    """

    results = []
    with driver.session() as session:
        records = session.run(
            query,
            module_ids=module_ids,
            visited=list(visited_modules),
        )
        for record in records:
            results.append({
                "from": record["start_id"],
                "id": record["id"],
                "name": record["name"],
                "type": record["type"],
                "rel_type": record["rel_type"],
                "rel_desc": record["rel_desc"],
            })

    return results


def close_driver() -> None:
    driver.close()
