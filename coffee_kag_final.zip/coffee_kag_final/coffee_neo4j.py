import os
import re
from neo4j import GraphDatabase

from config import URI, USER, PASSWORD


FILE_PATH = "realistic_coffee_machine_model.puml"


def load_puml(file_path: str) -> str:
    print(f"📂 读取文件: {file_path}")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"找不到文件: {file_path}；当前目录: {os.getcwd()}")
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()


def parse_nodes(puml_text: str):
    node_pattern = re.compile(
        r'class\s+"([^"]+)"\s+as\s+([A-Za-z0-9_]+)\s+<<([^>]+)>>'
    )
    nodes = []
    for name, alias, node_type in node_pattern.findall(puml_text):
        nodes.append({
            "id": alias.strip(),
            "name": name.strip(),
            "type": node_type.strip(),
        })
    return nodes


def parse_relationships(puml_text: str):
    rel_pattern = re.compile(
        r'^\s*([A-Za-z0-9_]+)\s+(\*--|\.\.>|-->|--)\s+([A-Za-z0-9_]+)(?:\s*:\s*(.+))?\s*$'
    )
    relationships = []

    for raw_line in puml_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("'") or line.startswith("@"):
            continue
        if line.startswith("skinparam") or line.startswith("left to right"):
            continue

        match = rel_pattern.match(line)
        if not match:
            continue

        source, arrow, target, desc = match.groups()
        desc = desc.strip() if desc else ""

        if arrow == "*--":
            rel_type = "COMPOSITION"
        elif arrow == "..>":
            rel_type = "DEPENDENCY"
        elif arrow == "-->":
            rel_type = "FLOW"
        elif arrow == "--":
            rel_type = "ASSOCIATION"
        else:
            rel_type = "RELATED_TO"

        relationships.append({
            "source": source,
            "target": target,
            "arrow": arrow,
            "type": rel_type,
            "desc": desc,
        })

    return relationships


def clear_database(tx):
    tx.run("MATCH (n) DETACH DELETE n")


def create_constraints(tx):
    tx.run(
        """
        CREATE CONSTRAINT sysml_element_id_unique IF NOT EXISTS
        FOR (n:SysML_Element)
        REQUIRE n.id IS UNIQUE
        """
    )


def create_node(tx, node):
    tx.run(
        """
        MERGE (n:SysML_Element {id: $id})
        SET n.name = $name,
            n.type = $type
        """,
        node,
    )


def create_relationship(tx, rel):
    rel_type = rel["type"]
    if rel_type not in {"COMPOSITION", "DEPENDENCY", "FLOW", "ASSOCIATION", "RELATED_TO"}:
        rel_type = "RELATED_TO"

    query = f"""
    MATCH (a:SysML_Element {{id: $source}})
    MATCH (b:SysML_Element {{id: $target}})
    MERGE (a)-[r:{rel_type}]->(b)
    SET r.arrow = $arrow,
        r.desc = $desc
    """
    tx.run(
        query,
        {
            "source": rel["source"],
            "target": rel["target"],
            "arrow": rel["arrow"],
            "desc": rel["desc"],
        },
    )


def import_to_neo4j(nodes, relationships, clear_first: bool = True):
    driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))
    driver.verify_connectivity()
    print("✅ Neo4j 连接成功")

    with driver.session() as session:
        if clear_first:
            session.execute_write(clear_database)
        session.execute_write(create_constraints)

        for node in nodes:
            session.execute_write(create_node, node)

        for rel in relationships:
            session.execute_write(create_relationship, rel)

    driver.close()
    print("🎉 导入完成")


def main():
    puml_text = load_puml(FILE_PATH)
    nodes = parse_nodes(puml_text)
    relationships = parse_relationships(puml_text)

    print(f"✅ 解析到 {len(nodes)} 个节点")
    print(f"✅ 解析到 {len(relationships)} 条关系")
    print("前 5 个节点：", nodes[:5])
    print("前 10 条关系：", relationships[:10])

    import_to_neo4j(nodes, relationships, clear_first=True)


if __name__ == "__main__":
    main()
