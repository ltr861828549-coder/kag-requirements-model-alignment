import re
from typing import Any

from langchain_core.messages import HumanMessage, AIMessage

from conversation_state import ConversationState
from llm_chains import CoffeeLLMChains
from graph_tools import (
    find_module_candidates,
    get_multihop_paths,
    collect_impacted_modules,
    build_graph_context,
    build_analysis_graph_json,
    save_analysis_json,
    expand_from_frontier,
    close_driver,
)
from file_chat_history import FileChatMessageHistory
from config import MAX_HOPS


class CoffeeChangeAgent:
    def __init__(self, session_id: str, max_hops: int = MAX_HOPS, save_json: bool = True):
        self.session_id = session_id
        self.max_hops = max_hops
        self.save_json = save_json

        self.llm_chains = CoffeeLLMChains()
        self.state = ConversationState(session_id=session_id)
        self.history = FileChatMessageHistory(
            session_id=session_id,
            storage_path="./chat_history"
        )

    def classify_intent(self, user_question: str) -> str:
        q = user_question.strip()

        if any(word in q for word in ["这些部件", "这些模块", "它们", "继续", "再往后", "然后呢", "接下来", "继续扩散"]):
            return "continue_impact"
        if any(word in q for word in ["为什么", "原因", "为何"]):
            return "reason"
        if any(word in q for word in ["怎么改", "如何改", "修改建议", "建议", "怎么调整", "如何调整"]):
            return "suggest"
        if any(word in q for word in ["影响", "波及", "关联", "涉及", "更改", "修改", "增加", "新增", "变更", "删除"]):
            return "impact"
        return "impact"

    def extract_quoted_module(self, user_question: str) -> str | None:
        patterns = [
            r'“([^”]+)”',
            r'"([^"]+)"',
            r"'([^']+)'",
            r'《([^》]+)》',
        ]
        for pattern in patterns:
            m = re.search(pattern, user_question)
            if m:
                text = m.group(1).strip()
                if text:
                    return text
        return None

    def _extract_id_from_question(self, user_question: str) -> str | None:
        match = re.search(r'\b(?:P|SS|CM)\d+\b', user_question, re.IGNORECASE)
        if match:
            return match.group(0)
        return None

    def extract_module_from_question(self, user_question: str) -> str:
        quoted = self.extract_quoted_module(user_question)
        if quoted:
            return quoted

        node_id = self._extract_id_from_question(user_question)
        if node_id:
            return node_id

        return user_question.strip()

    def _score_candidate(self, candidate: dict[str, Any], raw_module: str) -> int:
        score = 0
        cand_id = str(candidate.get("id", ""))
        cand_name = str(candidate.get("name", ""))
        cand_type = str(candidate.get("type", ""))

        if raw_module.lower() == cand_id.lower():
            score += 100
        if raw_module == cand_name:
            score += 95
        if raw_module and raw_module in cand_name:
            score += 60 + len(raw_module)

        type_bonus = {
            "Part": 15,
            "Block": 14,
            "Sensor": 12,
            "Actuator": 12,
            "Function": 10,
            "System": 6,
        }
        score += type_bonus.get(cand_type, 0)
        return score

    def choose_best_module(self, user_question: str) -> dict[str, Any]:
        raw_module = self.extract_module_from_question(user_question)
        candidates = find_module_candidates(raw_module)
        if not candidates:
            return {}
        candidates.sort(key=lambda c: self._score_candidate(c, raw_module), reverse=True)
        return candidates[0]

    def get_module_suggestions(self, user_question: str, limit: int = 5) -> list[dict[str, Any]]:
        raw_module = self.extract_module_from_question(user_question)
        candidates = find_module_candidates(raw_module, limit=limit)
        candidates.sort(key=lambda c: self._score_candidate(c, raw_module), reverse=True)
        return candidates[:limit]

    def ask(self, user_question: str) -> str:
        intent = self.classify_intent(user_question)

        if intent == "continue_impact":
            answer = self._handle_continue_impact()
            self._append_history(user_question, answer)
            return answer

        chosen = self.choose_best_module(user_question)
        if not chosen:
            suggestions = self.get_module_suggestions(user_question)
            if suggestions:
                suggestion_text = "；".join([f"{item['name']}({item['id']})" for item in suggestions])
                answer = (
                    "我暂时没有唯一定位到你说的模块。"
                    f"请把要变更的模块放在引号里，例如“功能按键板”；当前候选有：{suggestion_text}。"
                )
            else:
                answer = "我没有在知识图谱中找到对应模块。请把模块名写在引号里，例如：如果“功能按键板”要增加音量调节功能，会影响什么？"
            self._append_history(user_question, answer)
            return answer

        module_id = chosen["id"]
        module_name = chosen.get("name", module_id)
        paths = get_multihop_paths(module_id, max_hops=self.max_hops)

        if not paths:
            answer = f"图谱中已定位到模块 {module_name}({module_id})，但没有检索到从它出发的多跳影响路径。"
            self._append_history(user_question, answer)
            return answer

        impacted = collect_impacted_modules(paths)
        impacted_ids = list(impacted.keys())
        context = build_graph_context(module_id, paths)

        self.state.update_from_analysis(
            query_module=module_id,
            impacted_modules=impacted_ids,
            paths=paths,
        )
        self.state.save()

        module_label = f"{module_name}({module_id})"
        if intent == "impact":
            answer = self.llm_chains.ask_impact(module_id=module_label, context=context)
        elif intent == "suggest":
            answer = self.llm_chains.ask_suggest(module_id=module_label, context=context)
        elif intent == "reason":
            answer = self._handle_reason(user_question, module_id, paths)
        else:
            answer = self.llm_chains.ask_impact(module_id=module_label, context=context)

        if self.save_json:
            analysis_json = build_analysis_graph_json(
                start_module=chosen,
                paths=paths,
                user_question=user_question,
                intent=intent,
                llm_answer=answer,
            )
            file_path = save_analysis_json(analysis_json)
            answer = answer + f"\n\n已同步生成图谱 JSON 文件：{file_path}"

        self._append_history(user_question, answer)
        return answer

    def _handle_continue_impact(self) -> str:
        if not self.state.has_frontier():
            return "当前没有可以继续扩散的上一轮结果，请先明确给出一个起始模块。"

        previous_frontier = self.state.last_frontier[:]
        expansion = expand_from_frontier(module_ids=previous_frontier, visited_modules=self.state.visited_modules)
        if not expansion:
            return "基于上一轮受影响模块继续扩散后，没有发现新的受影响模块。"

        new_modules = []
        seen = set()
        for item in expansion:
            node_id = item["id"]
            if node_id not in seen:
                seen.add(node_id)
                new_modules.append(node_id)

        self.state.update_frontier(new_modules)
        self.state.save()

        readable_lines = []
        for item in expansion:
            readable_lines.append(f"{item['from']} -[{item['rel_type']}:{item['rel_desc']}]-> {item['id']} ({item['name']})")

        context = {
            "last_query_module": self.state.last_query_module,
            "previous_frontier": previous_frontier,
            "new_frontier": new_modules,
            "visited_modules": list(self.state.visited_modules),
            "expansion_paths": readable_lines,
        }

        return self.llm_chains.ask_continue(context=context)

    def _extract_target_module_for_reason(self, user_question: str, source_module_id: str) -> str | None:
        quoted = self.extract_quoted_module(user_question)
        if quoted:
            suggestions = find_module_candidates(quoted)
            for item in suggestions:
                if item["id"].lower() != source_module_id.lower():
                    return item["id"]

        ids = re.findall(r'\b(?:P|SS|CM)\d+\b', user_question, re.IGNORECASE)
        for token in ids:
            if token.lower() != source_module_id.lower():
                return token
        return None

    def _handle_reason(self, user_question: str, module_id: str, paths: list[dict[str, Any]]) -> str:
        target_module = self._extract_target_module_for_reason(user_question, module_id)
        if not target_module:
            return "你提到了原因解释，但没有明确说明要解释哪个目标模块。建议把目标模块也放在引号里。"

        related_paths = []
        for path in paths:
            node_ids = [node["id"] for node in path["nodes"]]
            if target_module in node_ids[1:]:
                related_paths.append(path)

        if not related_paths:
            return f"从 {module_id} 出发的路径中，没有找到影响 {target_module} 的证据。"

        context = build_graph_context(module_id, related_paths)
        return self.llm_chains.ask_reason(module_id=module_id, target_module=target_module, context=context)

    def reset_state(self) -> None:
        self.state.clear()

    def _append_history(self, user_question: str, answer: str) -> None:
        try:
            self.history.add_messages([
                HumanMessage(content=user_question),
                AIMessage(content=answer),
            ])
        except Exception:
            pass

    def close(self) -> None:
        try:
            close_driver()
        except Exception:
            pass
