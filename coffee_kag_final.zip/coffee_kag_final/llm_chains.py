import json

from langchain_community.chat_models.tongyi import ChatTongyi
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from config import MODEL_NAME


class CoffeeLLMChains:
    def __init__(self, model_name: str = MODEL_NAME):
        self.llm = ChatTongyi(model=model_name)
        self.parser = StrOutputParser()

        self.impact_chain = self._build_impact_chain()
        self.reason_chain = self._build_reason_chain()
        self.suggest_chain = self._build_suggest_chain()
        self.continue_chain = self._build_continue_chain()

    def _build_impact_chain(self):
        prompt = ChatPromptTemplate.from_messages([
            (
                "system",
                "你是一个面向需求模型变更分析的知识图谱助手。"
                "请根据图谱中的多跳路径证据，分析一个模块发生变更后会影响哪些模块。"
                "回答时要分清‘图谱直接证据’与‘工程上的合理推断’，不要把推断说成图谱里已经存在。"
                "回答‘受影响的模块该怎么修改？’时，要结合图谱证据和工程常识，给出具体的修改建议，而不是泛泛地说‘需要修改’。"
                "最后加一个很短的小结。"
            ),
            (
                "human",
                "变更模块：{module_id}\n\n"
                "图谱证据如下：\n{context}\n\n"
                "请回答：\n"
                "1. 受影响模块有哪些\n"
                "2. 哪些属于直接影响，哪些属于间接影响\n"
                "3. 每个模块为什么受影响\n"
                "4. 哪些属于图谱直接证据，哪些属于工程推断\n"
                "5. 受影响的模块该怎么修改？\n"
                "6. 建议优先检查哪些模块"
            )
        ])
        return prompt | self.llm | self.parser

    def _build_reason_chain(self):
        prompt = ChatPromptTemplate.from_messages([
            (
                "system",
                "你是一个需求模型变更解释助手。你的任务是根据知识图谱路径证据，解释某个目标模块为什么会受到影响。"
                "请明确指出它位于第几跳，以及经过了哪些关系路径。"
            ),
            (
                "human",
                "起始变更模块：{module_id}\n"
                "目标模块：{target_module}\n\n"
                "相关图谱证据如下：\n{context}\n\n"
                "请解释目标模块为什么会受到影响。"
            )
        ])
        return prompt | self.llm | self.parser

    def _build_suggest_chain(self):
        prompt = ChatPromptTemplate.from_messages([
            (
                "system",
                "你是一个需求模型修改建议助手。请根据多跳传播路径，给出模型修改建议。"
                "建议从结构、依赖、接口、约束四个角度组织回答，并补充需要同步更新的图谱节点或关系。"
            ),
            (
                "human",
                "变更模块：{module_id}\n\n"
                "图谱证据如下：\n{context}\n\n"
                "请输出：\n"
                "1. 应优先修改的模块\n"
                "2. 每个模块的建议修改动作\n"
                "3. 哪些节点关系也需要同步更新\n"
                "4. 修改时的注意点"
            )
        ])
        return prompt | self.llm | self.parser

    def _build_continue_chain(self):
        prompt = ChatPromptTemplate.from_messages([
            (
                "system",
                "你是一个需求变更传播分析助手。当前用户的问题是在上一轮受影响模块的基础上继续向外扩散。"
                "请根据新扩散得到的模块和扩散路径，说明新一层可能受影响的部件。"
            ),
            (
                "human",
                "继续扩散的上下文如下：\n{context}\n\n"
                "请说明：\n"
                "1. 新增受影响模块有哪些\n"
                "2. 它们是由哪些上一轮模块继续传播而来的\n"
                "3. 这些新增模块意味着后续应关注什么"
            )
        ])
        return prompt | self.llm | self.parser

    def ask_impact(self, module_id: str, context: str) -> str:
        return self.impact_chain.invoke({
            "module_id": module_id,
            "context": context,
        })

    def ask_reason(self, module_id: str, target_module: str, context: str) -> str:
        return self.reason_chain.invoke({
            "module_id": module_id,
            "target_module": target_module,
            "context": context,
        })

    def ask_suggest(self, module_id: str, context: str) -> str:
        return self.suggest_chain.invoke({
            "module_id": module_id,
            "context": context,
        })

    def ask_continue(self, context: dict) -> str:
        return self.continue_chain.invoke({
            "context": json.dumps(context, ensure_ascii=False, indent=2)
        })
