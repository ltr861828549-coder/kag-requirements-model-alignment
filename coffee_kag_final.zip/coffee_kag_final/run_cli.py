from change_agent import CoffeeChangeAgent

""" 
测试用例：
如果“功能按键板”要增加一个音量调节功能，请给我输出受影响模块分析，并生成 JSON 文件
我想要删除“废水盘”，让废水直接排入下水管中，请给我输出受影响模块分析，并生成 JSON 文件
我想要更改“水泵”的型号为ULKA-EP5，请给我输出受影响模块分析，并生成 JSON 文件
"""



def main():
    agent = CoffeeChangeAgent(session_id="default_session", max_hops=3)
    print("模型修改客服已启动，模块名请放在引号""里，输入 quit / exit 退出。")

    try:
        while True:
            question = input("\n你：").strip()
            if question.lower() in {"quit", "exit"}:
                print("已退出。")
                break
            if not question:
                continue
            answer = agent.ask(question)
            print("\n客服：")
            print(answer)
    finally:
        agent.close()


if __name__ == "__main__":
    main()
