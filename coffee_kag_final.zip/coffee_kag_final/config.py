from dataclasses import dataclass


@dataclass
class Neo4jConfig:
    uri: str = "bolt://localhost:7687"
    user: str = "neo4j"
    password: str = "use_your_password"


@dataclass
class ModelConfig:
    # use your own model name, e.g., "qwen3-max" or "qwen2.5-max"
    # you can also use "qwen3-mini" or "qwen2.5-mini" 
    # input your own api key in .env file, e.g., QWEN_API_KEY=your_api_key
    MODEL_NAME: str = "qwen3-max"
    max_hops: int = 3


NEO4J_CONFIG = Neo4jConfig()
MODEL_CONFIG = ModelConfig()

# 兼容旧写法 / 其他模块直接导入
URI = NEO4J_CONFIG.uri
USER = NEO4J_CONFIG.user
PASSWORD = NEO4J_CONFIG.password

MODEL_NAME = MODEL_CONFIG.MODEL_NAME
MAX_HOPS = MODEL_CONFIG.max_hops