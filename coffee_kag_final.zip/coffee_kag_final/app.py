import json
import re
import uuid
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Demand Model Alignment System",
    page_icon="✨",
    layout="wide",
    initial_sidebar_state="collapsed",
)

JSON_PATH_PATTERN = r"已同步生成图谱 JSON 文件：(.+)"
DEFAULT_SESSION_PREFIX = "streamlit"


@st.cache_resource
def load_agent(session_id: str):
    try:
        from change_agent import CoffeeChangeAgent  # type: ignore
        return CoffeeChangeAgent(session_id=session_id, save_json=True)
    except Exception as e:
        return e


def init_state() -> None:
    if "session_id" not in st.session_state:
        st.session_state.session_id = f"{DEFAULT_SESSION_PREFIX}_{uuid.uuid4().hex[:8]}"
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "last_json_path" not in st.session_state:
        st.session_state.last_json_path = None
    if "last_json_data" not in st.session_state:
        st.session_state.last_json_data = None
    if "pending_prompt" not in st.session_state:
        st.session_state.pending_prompt = None


def extract_json_path(answer: str) -> str | None:
    match = re.search(JSON_PATH_PATTERN, answer)
    if not match:
        return None
    raw = match.group(1).strip().strip('"').strip("'")
    return raw


def safe_read_json(json_path: str | None) -> dict[str, Any] | None:
    if not json_path:
        return None
    try:
        p = Path(json_path)
        if not p.is_absolute():
            p = Path.cwd() / p
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def inject_global_style() -> None:
    st.markdown(
        """
        <style>
    
        :root {
            --bg: #0b1020;
            --bg-soft: rgba(255,255,255,0.05);
            --card: rgba(18, 24, 45, 0.78);
            --card-2: rgba(255,255,255,0.04);
            --stroke: rgba(255,255,255,0.09);
            --text: #f4f7fb;
            --muted: #9ca8c3;
            --accent: #6d7cff;
            --accent-2: #25c7d9;
            --gold: #f4c96a;
            --shadow: 0 20px 60px rgba(0,0,0,0.28);
            --radius-xl: 24px;
            --radius-lg: 18px;
            --radius-md: 14px;
        }

        /* 强制隐藏 Streamlit 默认的页脚和多余空间 */
        #MainMenu {visibility: visible !important;}
        footer {visibility: hidden;}

        html, body, [class*="css"] {
            font-family: 'Inter', 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
        }

        .stApp {
            color: var(--text);
            background:
                radial-gradient(circle at top left, rgba(93, 106, 255, 0.20), transparent 28%),
                radial-gradient(circle at 85% 12%, rgba(37, 199, 217, 0.18), transparent 24%),
                linear-gradient(180deg, #0a0f1d 0%, #0b1222 52%, #0b1020 100%);
            overflow: auto; /* 允许外层 scrolling，避免刷新后滚动条“消失” */
        }

        .block-container {
            padding-top: 0.5rem !important;
            padding-bottom: 0.5rem !important;
            padding-left: 2rem !important;
            padding-right: 2rem !important;
            max-width: 1600px;
        }

        [data-testid="stHeader"] {
            background: rgba(0,0,0,0);
        }

        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, rgba(13,18,35,0.95), rgba(10,14,28,0.95));
            border-right: 1px solid var(--stroke);
        }

        .hero-shell {
            position: relative;
            overflow: hidden;
            padding: 1.25rem 1.35rem 1.15rem 1.35rem;
            border-radius: 28px;
            background: linear-gradient(135deg, rgba(22,29,53,0.92), rgba(12,17,32,0.88));
            border: 1px solid rgba(255,255,255,0.10);
            box-shadow: var(--shadow);
            margin-bottom: 0.95rem;
        }

        .hero-shell::before {
            content: "";
            position: absolute;
            inset: 0;
            background:
                radial-gradient(circle at 8% 0%, rgba(109,124,255,0.28), transparent 28%),
                radial-gradient(circle at 100% 0%, rgba(37,199,217,0.18), transparent 24%);
            pointer-events: none;
        }

        .hero-row {
            position: relative;
            z-index: 2;
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .hero-title {
            font-size: 1.62rem;
            font-weight: 800;
            letter-spacing: -0.03em;
            color: #ffffff;
            margin: 0;
        }

        .hero-subtitle {
            margin-top: 0.32rem;
            color: var(--muted);
            font-size: 0.95rem;
            line-height: 1.55;
        }

        .hero-badges {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .hero-badge {
            padding: 0.55rem 0.8rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.09);
            color: #eaf0ff;
            font-size: 0.82rem;
            backdrop-filter: blur(10px);
        }

        /* 卡片容器优化 */
        .section-card {
            background: linear-gradient(180deg, rgba(18,24,45,0.88), rgba(11,16,31,0.82));
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 16px;
            padding: 0.7rem 0.8rem;
            height: 100%;
        }

        .section-title {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            padding-bottom: 0.4rem;
        }

        .section-title h3 {
            margin: 0;
            font-size: 1rem;
            font-weight: 700;
            color: #ffffff;
            letter-spacing: -0.02em;
        }

        .section-title span {
            color: var(--muted);
            font-size: 0.8rem;
        }

        [data-testid="stChatMessage"] {
            background: transparent;
            border: none;
            padding: 0;
        }

        [data-testid="stChatMessageContent"] {
            width: 100%;
        }

        /* 对话气泡微调 */
        .chat-wrap {
            border-radius: 12px;
            padding: 0.6rem 0.8rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .chat-user {
            background: linear-gradient(180deg, rgba(109,124,255,0.16), rgba(109,124,255,0.08));
            border: 1px solid rgba(109,124,255,0.24);
        }

        .chat-assistant {
            background: linear-gradient(180deg, rgba(255,255,255,0.045), rgba(255,255,255,0.03));
            border: 1px solid rgba(255,255,255,0.08);
        }

        .chat-meta {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            margin-bottom: 0.55rem;
            color: #d7def3;
            font-size: 0.86rem;
            font-weight: 600;
        }

        .chat-dot {
            width: 8px;
            height: 8px;
            border-radius: 999px;
            background: var(--accent-2);
            box-shadow: 0 0 18px rgba(37,199,217,0.65);
        }

        .chat-user .chat-dot {
            background: var(--gold);
            box-shadow: 0 0 18px rgba(244,201,106,0.6);
        }

        .metric-card {
            padding: 0.9rem 0.9rem 0.75rem 0.9rem;
            border-radius: 18px;
            background: rgba(255,255,255,0.045);
            border: 1px solid rgba(255,255,255,0.07);
            min-height: 88px;
        }

        .metric-label {
            color: var(--muted);
            font-size: 0.8rem;
            margin-bottom: 0.2rem;
        }

        .metric-value {
            color: #ffffff;
            font-size: 1.55rem;
            font-weight: 800;
            letter-spacing: -0.03em;
        }

        .mini-card {
            border-radius: 18px;
            padding: 0.95rem 1rem;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
        }

        .mini-kv {
            display: grid;
            grid-template-columns: 92px 1fr;
            row-gap: 0.45rem;
            column-gap: 0.8rem;
            font-size: 0.88rem;
        }

        .mini-kv .k {
            color: var(--muted);
        }

        .mini-kv .v {
            color: #eef2ff;
            word-break: break-word;
        }

        .sample-chip {
            padding: 0.65rem 0.8rem;
            border-radius: 14px;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
        }

        .stButton > button {
            width: 100%;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,0.09);
            color: #f7f9ff;
            background: linear-gradient(180deg, rgba(255,255,255,0.07), rgba(255,255,255,0.04));
            padding: 0.68rem 0.9rem;
            font-weight: 600;
            transition: all .18s ease;
        }

        .stButton > button:hover {
            border-color: rgba(109,124,255,0.45);
            background: linear-gradient(180deg, rgba(109,124,255,0.20), rgba(109,124,255,0.10));
            color: #ffffff;
        }

        [data-testid="stChatInput"] {
            background: rgba(255,255,255,0.035);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 18px;
            padding: 0.22rem 0.35rem;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.02);
        }

        .stTextInput input {
            border-radius: 14px !important;
        }

        /* 聊天滚动框与 JSON 结果区域处理，避免页面溢出 */
        .scroll-box {
            max-height: 520px;
            overflow-y: auto;
            padding-right: 8px;
        }

        .dataframe-box {
            max-height: 340px;
            overflow-y: auto;
        }

        .json-box {
            max-height: 430px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-all;
            background: rgba(10,14,28,0.65);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 10px;
            padding: 0.55rem;
        }

        /* 限制默认 Chat 消息容器高度，避免刷新抖动*/
        [data-testid="stChatMessage"] {
            max-height: 520px;
            overflow-y: auto;
        }

        [data-testid="stChatMessageContent"] {
            max-height: 520px;
            overflow-wrap: break-word;
            white-space: pre-wrap;
        }

        /* 针对数据表格的优化 */
        div[data-testid="stDataFrame"] {
            height: 300px !important;
        }

        .stTabs [data-baseweb="tab-list"] {
            gap: 0.45rem;
            margin-bottom: 0.4rem;
        }

        .stTabs [data-baseweb="tab"] {
            background: rgba(255,255,255,0.035);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 12px;
            padding: 0.45rem 0.8rem;
        }

        .stTabs [aria-selected="true"] {
            background: rgba(109,124,255,0.14) !important;
            border-color: rgba(109,124,255,0.35) !important;
        }

        .stDownloadButton > button {
            border-radius: 14px;
        }

        .tiny-note {
            margin-top: 0.3rem;
            color: var(--muted);
            font-size: 0.79rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_topbar() -> None:
    total_messages = len(st.session_state.get("messages", []))
    has_json = "已就绪" if st.session_state.get("last_json_data") else "等待分析"
    st.markdown(
        f"""
        <div class="hero-shell">
            <div class="hero-row">
                <div>
                    <div class="hero-title">✨ Demand Model Alignment System</div>
                    <div class="hero-subtitle">
                        基于 KAG 的需求变更分析与模型对齐前端展示。保留对话式交互，强化答辩演示时的视觉层次、数据质感与结构化呈现。
                    </div>
                </div>
                <div class="hero-badges">
                    <div class="hero-badge">Session · {st.session_state.session_id}</div>
                    <div class="hero-badge">Messages · {total_messages}</div>
                    <div class="hero-badge">JSON · {has_json}</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar() -> None:
    with st.sidebar:
        st.markdown("### 控制台")
        st.text_input("Session ID", key="session_id")
        st.caption("同一个 Session ID 会复用后端状态与聊天历史。")

        col1, col2 = st.columns(2)
        with col1:
            if st.button("清空对话"):
                st.session_state.messages = []
                st.session_state.last_json_path = None
                st.session_state.last_json_data = None
                st.rerun()
        with col2:
            if st.button("刷新界面"):
                st.rerun()

        st.markdown("### 示例提问")
        examples = [
            '如果“功能按键板”增加音量调节功能，会影响什么？',
            '为什么“功能按键板”会影响“主控模块”？',
            '如果“加热模块”变更，相关模块需要怎么调整？',
            '继续扩散',
        ]
        for q in examples:
            if st.button(q, key=f"ex_{q}", use_container_width=True):
                st.session_state.pending_prompt = q

        st.markdown('<div class="tiny-note">建议答辩时使用较短问题连续演示，这样右侧图谱与 JSON 面板会更稳定、更清晰。</div>', unsafe_allow_html=True)


def render_chat_message(role: str, content: str) -> None:
    label = "You" if role == "user" else "Assistant"
    card_cls = "chat-wrap chat-user" if role == "user" else "chat-wrap chat-assistant"
    st.markdown(
        f'<div class="{card_cls}"><div class="chat-meta"><span class="chat-dot"></span><span>{label}</span></div>',
        unsafe_allow_html=True,
    )
    st.markdown(content)
    st.markdown('</div>', unsafe_allow_html=True)


def render_chat() -> None:

    prompt = st.session_state.pop("pending_prompt", None)
    user_input = st.chat_input("输入需求变更问题，例如：如果“功能按键板”增加音量调节功能，会影响什么？")

    if prompt is None:
        prompt = user_input

    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        agent = load_agent(st.session_state.session_id)

        with st.spinner("正在分析图谱影响路径与模型对齐建议..."):
            if isinstance(agent, Exception):
                answer = (
                    "后端加载失败，当前前端无法调用 `CoffeeChangeAgent`。\n\n"
                    f"错误信息：`{type(agent).__name__}: {agent}`\n\n"
                    "请确认 `change_agent.py`、`graph_tools.py`、`config.py` 以及依赖环境可用。"
                )
            else:
                try:
                    answer = agent.ask(prompt)
                except Exception as e:
                    answer = f"后端运行失败：`{type(e).__name__}: {e}`"

        st.session_state.messages.append({"role": "assistant", "content": answer})
        json_path = extract_json_path(answer)
        json_data = safe_read_json(json_path)
        st.session_state.last_json_path = json_path
        st.session_state.last_json_data = json_data

    # 关键修改：将高度从 720 降低到 520，以适应一屏显示。使用 Streamlit container 以保证嵌套有效。
    with st.container(height=520):
        if not st.session_state.messages:
            st.markdown('<div style="color:#9ca8c3; font-size:0.85rem;">等待输入问题以开始分析...</div>', unsafe_allow_html=True)
        else:
            for msg in st.session_state.messages:
                render_chat_message(msg["role"], msg["content"])


def make_impacted_df(data: dict[str, Any]) -> pd.DataFrame:
    rows = data.get("impacted_modules", []) or []
    if not rows:
        return pd.DataFrame(columns=["id", "name", "type", "min_hop", "path_count", "via_relation_types"])
    df = pd.DataFrame(rows)
    if "via_relation_types" in df.columns:
        df["via_relation_types"] = df["via_relation_types"].apply(
            lambda x: ", ".join(x) if isinstance(x, list) else x
        )
    return df


def build_graphviz(data: dict[str, Any]) -> str:
    nodes = data.get("nodes", []) or []
    edges = data.get("edges", []) or []

    lines = [
        "digraph G {",
        'rankdir=LR;',
        'graph [pad="0.35", nodesep="0.45", ranksep="0.8", bgcolor="transparent", fontname="Microsoft YaHei"];',
        'node [shape=box, style="rounded,filled", fontname="Microsoft YaHei", margin="0.18,0.10", color="#9fb6ff", penwidth=1.0];',
        'edge [fontname="Microsoft YaHei", color="#7d88aa", arrowsize=0.8];',
    ]

    for node in nodes:
        node_id = str(node.get("id", ""))
        name = str(node.get("name", node_id))
        role = str(node.get("role", "impacted_module"))
        node_type = str(node.get("type", "Unknown"))
        hop = node.get("hop", "")
        label = f"{name}\\n({node_id})\\n{node_type} · hop={hop}"

        if role == "changed_module":
            fill = "#f4c96a"
            font = "#1b1b1b"
            border = "#f7d98f"
        else:
            fill = "#dfe8ff"
            font = "#15203b"
            border = "#a9bbff"

        lines.append(
            f'"{node_id}" [label="{label}", fillcolor="{fill}", fontcolor="{font}", color="{border}"];'
        )

    for edge in edges:
        src = str(edge.get("source", ""))
        dst = str(edge.get("target", ""))
        rel_type = str(edge.get("type", "RELATED_TO"))
        desc = str(edge.get("desc", ""))
        edge_label = rel_type if not desc else f"{rel_type}\\n{desc}"
        lines.append(f'"{src}" -> "{dst}" [label="{edge_label}"];')

    lines.append("}")
    return "\n".join(lines)


def metric_box(label: str, value: Any) -> None:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-label">{label}</div>
            <div class="metric-value">{value}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_json_panel() -> None:
    st.markdown(
        """
        <div class="section-card">
            <div class="section-title">
                <h3>结构化分析面板</h3>
                <span>Impact modules · Graph view · Raw JSON</span>
            </div>
        """,
        unsafe_allow_html=True,
    )

    json_path = st.session_state.get("last_json_path")
    data = st.session_state.get("last_json_data")

    if not data:
        st.markdown(
            """
            <div class="mini-card">
                <div style="font-size:1rem;font-weight:700;color:#fff;margin-bottom:0.4rem;">等待结构化结果</div>
                <div style="color:#9ca8c3;line-height:1.7;">
                    当左侧完成一次变更分析后，这里会自动展示受影响模块、关系图、LLM 回答以及当前生成的 JSON 文件内容。
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        if json_path:
            st.warning(f"检测到 JSON 路径但读取失败：{json_path}")
        st.markdown('</div>', unsafe_allow_html=True)
        return

    summary = data.get("summary", {}) or {}
    meta = data.get("meta", {}) or {}
    start_module = meta.get("start_module", {}) or {}

    c1, c2 = st.columns(2)
    with c1:
        metric_box("节点数", summary.get("node_count", 0))
    with c2:
        metric_box("关系边数", summary.get("edge_count", 0))

    c3, c4 = st.columns(2)
    with c3:
        metric_box("受影响模块", summary.get("impacted_count", 0))
    with c4:
        metric_box("路径数", summary.get("path_count", 0))

    st.markdown(
        f"""
        <div class="mini-card" style="margin-top:0.75rem;margin-bottom:0.85rem;">
            <div style="font-size:0.95rem;font-weight:700;color:#fff;margin-bottom:0.65rem;">起始变更模块</div>
            <div class="mini-kv">
                <div class="k">ID</div><div class="v">{start_module.get('id', '')}</div>
                <div class="k">名称</div><div class="v">{start_module.get('name', '')}</div>
                <div class="k">类型</div><div class="v">{start_module.get('type', '')}</div>
                <div class="k">意图</div><div class="v">{meta.get('intent', '')}</div>
                <div class="k">生成时间</div><div class="v">{meta.get('generated_at', '')}</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    tab1, tab2, tab3, tab4 = st.tabs(["受影响模块", "关系图", "LLM 回答", "原始 JSON"])

    with tab1:
        df = make_impacted_df(data)
        st.dataframe(df, use_container_width=True, hide_index=True, height=320)

    with tab2:
        dot = build_graphviz(data)
        st.graphviz_chart(dot, use_container_width=True)

    with tab3:
        llm_answer = data.get("llm_answer", "")
        st.markdown(llm_answer if llm_answer else "没有记录到 llm_answer。")

    with tab4:
        raw_text = json.dumps(data, ensure_ascii=False, indent=2)
        st.text_area("原始 JSON", value=raw_text, height=380, key="json_raw_output")
        filename = Path(json_path).name if json_path else "analysis_result.json"
        st.download_button(
            "下载当前 JSON",
            data=raw_text.encode("utf-8"),
            file_name=filename,
            mime="application/json",
            use_container_width=True,
        )

    st.markdown('</div>', unsafe_allow_html=True)

def metric_box(label: str, value: Any) -> None:
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{label}</div><div class="metric-value">{value}</div></div>',
        unsafe_allow_html=True,
    )

def main() -> None:
    init_state()
    inject_global_style()
    render_topbar()
    render_sidebar()

    left, right = st.columns([1.7, 1.05], gap="medium")
    with left:
        render_chat()
    with right:
        render_json_panel()


if __name__ == "__main__":
    main()
